import java.util.Scanner;

public class WarshallAlgorithm {
    final static int INF = 99999; // Use a large number to represent infinity

    // Function to print the solution matrix
    void printSolution(int reach[][], int V) {
        System.out.println("Following matrix is the transitive closure of the given graph:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                System.out.print(reach[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Function to compute the transitive closure using Warshall's algorithm
    void transitiveClosure(int graph[][], int V) {
        int reach[][] = new int[V][V];
        int i, j, k;

        // Initialize the reach matrix as the input graph matrix
        for (i = 0; i < V; i++) {
            for (j = 0; j < V; j++) {
                reach[i][j] = graph[i][j];
            }
        }

        // Update the reach matrix using Warshall's algorithm
        for (k = 0; k < V; k++) {
            for (i = 0; i < V; i++) {
                for (j = 0; j < V; j++) {
                    reach[i][j] = (reach[i][j] != 0) || ((reach[i][k] != 0) && (reach[k][j] != 0)) ? 1 : 0;
                }
            }
        }

        // Print the solution
        printSolution(reach, V);
}

public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Enter the number of vertices:");
    int V = scanner.nextInt();

    int graph[][] = new int[V][V];

    System.out.println("Enter the adjacency matrix (0 for no edge, 1 for edge):");
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            graph[i][j] = scanner.nextInt();
        }
    }

        WarshallAlgorithm wa = new WarshallAlgorithm();
        wa.transitiveClosure(graph, V);
    }
}