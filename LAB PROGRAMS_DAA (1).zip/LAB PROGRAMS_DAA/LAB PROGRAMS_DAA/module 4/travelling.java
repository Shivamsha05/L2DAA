import java.util.*;
class travelling{
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int c[][] = new int[10][10],tour[] = new int[10];
    int cost;
    System.out.println("enter the number of cities: ");
    int n = sc.nextInt();
    System.out.println("enter the cost matrix: ");
    for(int i=1;i<=n;i++){
      for(int j=1;j<=n;j++){
        c[i][j] = sc.nextInt();
      }
    }
    for(int i=1;i<=n;i++){
      tour[i] = i;
    }
    cost = tsp(c,tour,1,n);
    System.out.println("Accurate path is: ");
    for(int i=1;i<=n;i++){
      System.out.print(tour[i]+"->");
    }
    System.out.println("1");
    System.out.println("the accurate cost: "+cost);
  }
  static int tsp(int c[][],int tour[],int start,int n){
    int mintour[] = new int[10],temp[] = new int[10],mincost=999,ccost,i,j,k;
    if(start==n-1){
      return c[tour[n-1]][tour[n]] + c[tour[n]][1];
    }
    for(i = start+1;i<=n;i++){
      for(j=1;j<=n;j++){
        temp[j] = tour[j];
      }
      temp[start+1] = tour[i];
      temp[i] = tour[start+1];
      if(c[tour[start]][tour[i]]+(ccost = tsp(c,temp,start+1,n))<mincost){
        mincost = c[tour[start]][tour[i]]+ccost;
        for(k=1;k<=n;k++){
          mintour[k] = temp[k];
        }
      }
    }
    for(i=1;i<=n;i++){
      tour[i] = mintour[i];
    }
    return mincost;
  }
}
