import java.util.*;
import java.io.*;
class MergeSort{
  static int max=5000;
  void mergesort(int arr[],int l,int h){
    int mid;
    if(l<h){
      mid = (l+h)/2;
      mergesort(arr,l,mid);
      mergesort(arr,mid+1,h);
      merge(arr,l,mid,h);
    }
  }
  void merge(int arr[],int l,int mid,int h){
    int i,j,k;
    i = l;
    j = mid+1;
    k = l;
    int t[] = new int[max];
    while(i<=mid && j<=h){
      if(arr[i]<=arr[j]){
        t[k++] = arr[i++];
      }
      else{
        t[k++] = arr[j++];
      }
    }
    while(i<=mid){
      t[k++] = arr[i++];
    }
    while(j<=h){
      t[k++] = arr[j++];
    }
    for(i=l;i<=h;i++){
      arr[i] = t[i];
    }

  }
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter number of ele: ");
    int n = sc.nextInt();
    Random gen = new Random();
    int arr[] = new int[max];
    for(int i=0;i<n;i++){
      arr[i] = gen.nextInt(1000);
    }
    System.out.println("Random ele: ");
    for(int i=0;i<n;i++){
      System.out.print(arr[i]+" ");
    }
    System.out.println();
    long start = System.nanoTime();
    MergeSort qs = new MergeSort();
    qs.mergesort(arr,0,n-1);
    long stop = System.nanoTime();
    System.out.println("array after sorting: ");
    for(int i=0;i<n;i++){
        System.out.print(arr[i]+" ");
    }
    System.out.println("Time taken: "+(stop-start));
  }
}
