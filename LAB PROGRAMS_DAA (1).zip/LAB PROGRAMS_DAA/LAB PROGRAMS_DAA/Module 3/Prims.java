import java.util.*;
import java.io.*;
class Prims{
  void prim(int n,int arr[][]){
    int i,j,k,u,v;
    int d[] = new int[10];
    int s[] = new int[10];
    int p[] = new int[10];
    int t[][] = new int[10][2];
    int min=9999;
    int source = 0;
    for(i=0;i<n;i++){
      for(j=0;j<n;j++){
        if(arr[i][j]!=0 && arr[i][j]<=min){
          min = arr[i][j];
          source = i;
        }
      }
    }
    for(i=0;i<n;i++){
      d[i] = arr[source][i];
      s[i] = 0;
      p[i] = source;
    
    }
    s[source] = 1;
    int sum=0;
    k=0;
    for(i=1;i<n;i++){
      min=9999;
      u=-1;
      for(j=0;j<n;j++){
        if(s[j]==0){
          if(d[j]<min){
            min = d[j];
            u=j;
          }
        }
      }
      if(u==-1){
        return;
      }
      t[k][0]= u;
      t[k][1] = p[u];
      k++;
      sum = sum+arr[u][p[u]];
      s[u] = 1;
      for(v=0;v<n;v++){
        if(s[v]==0 && arr[u][v]<d[v]){
          d[v] = arr[u][v];
          p[v] = u;
        }
      }
    }
    if(sum>=9999){
      System.out.println("ST doesnot exists");
    }
    else{
      System.out.println("ST exists and min cost is : ");
      for(i=0;i<n-1;i++){
        System.out.println(t[i][0]+"->"+t[i][1]);
      }
      System.out.println("Cost of st: "+sum);
    }
  }
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int i,j,n;
    int arr[][] = new int[10][10];
    System.out.println("enter the number of nodes : ");
    n = sc.nextInt();
    System.out.println("enter the adj matrix : ");
    for(i=0;i<n;i++){
      for(j=0;j<n;j++){
        arr[i][j] = sc.nextInt();
      }
    }
    Prims p =new Prims();
    p.prim(n,arr);
  }
}
