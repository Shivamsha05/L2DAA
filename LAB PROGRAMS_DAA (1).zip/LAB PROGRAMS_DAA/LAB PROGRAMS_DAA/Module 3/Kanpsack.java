import java.util.*;
import java.io.*;
public class Kanpsack{
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of ele : ");
    int n = sc.nextInt();
    System.out.println("Enter the weight of each ele: ");
    float w[] = new float[10];
    for(int i=0;i<n;i++){
      w[i] = sc.nextFloat();
    }
    System.out.println("Enter profit : ");
    float p[] = new float[10];
    for(int i=0;i<n;i++){
      p[i] = sc.nextFloat();
    }
    System.out.println("Enter capacity : ");
    int m = sc.nextInt();
    float ratio[] = new float[10];
    for(int i=0;i<n;i++){
      ratio[i] = p[i]/w[i];
    }
    System.out.println("Information about knapsack : ");
    displayInfo(n,w,p,ratio);
    System.out.println("Capacity : " +m);
    sortArr(n,ratio,w,p);
    System.out.println("Details after sorting based on desc order of ratio : ");
    displayInfo(n,w,p,ratio);
    knapsack(m,n,w,p);
  }
  static void sortArr(int n,float ratio[],float w[],float p[]){
    int i,j;
    for(i=0;i<n;i++){
      for(j=0;j<n;j++){
        if(ratio[j]<ratio[j+1]){
          float temp = ratio[j];
          ratio[j] = ratio[j+1];
          ratio[j+1] = temp;
          temp = w[j];
          w[j] = w[j+1];
          w[j+1] = temp;
          temp = p[j];
          p[j]= p[j+1];
          p[j+1] = temp;
        }
      }
    }
  }
  static void displayInfo(int n,float w[],float p[],float ratio[]){
    System.out.println("Item\tWeight\tProfit\tRatio(profit/weight)");
    for(int i=0;i<n;i++){
      System.out.println(i+"\t"+w[i]+"\t"+p[i]+"\t"+ratio[i]);
    }
  }
  static void knapsack(int u,int n,float w[],float p[]){
    float x[] = new float[10],tp=0;
    int i,j;
    for(i=0;i<n;i++){
      x[i] = 0;
    }
    for(i=0;i<n;i++){
      if(w[i]>u){
        break;
      }
      else{
        x[i] = 1;
        tp=tp+p[i];
        u=(int)(u-w[i]);
      }
    }
    if(i<n)
      x[i] = u/w[i];
    tp = tp+(x[i]*p[i]);
    System.out.println("The result is : ");
    for(i=0;i<n;i++){
      System.out.println("\t"+x[i]);
    }
    System.out.println("MAx profit : "+tp );
  }

}
