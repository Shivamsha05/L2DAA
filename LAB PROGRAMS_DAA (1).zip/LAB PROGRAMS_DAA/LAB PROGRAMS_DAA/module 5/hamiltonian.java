import java.util.*;
import java.io.*;
import java.util.Arrays;
class hamiltonian{
  private static int V,pc;
  private static int path[];
  private static int graph[][];
  static void findCycle(int g[][]){
    V = g.length;
    path =new int[V];
    Arrays.fill(path,-1);
    graph = g;
    try{
      pc =1;
      path[0] = 0;
      solve(0);
      System.out.println("no slution");
    }
    catch(Exception e){
      System.out.println(e.getMessage());
      display();
    }
  }
  static void solve(int vertex) throws Exception{
    if(graph[vertex][0]==1 && pc==V){
      throw new Exception ("solution found");
    }
    if(pc==V){
      return;
    }
    for(int v=0;v<V;v++){
      if(graph[vertex][v]==1){
        path[pc++]=v;
        graph[vertex][v] = graph[v][vertex] = 0;
        if(!isPresent(v)){
          solve(v);
        }
        graph[vertex][v] = graph[v][vertex] = 1;
        path[--pc]=-1;
      }
    }
  }
  static boolean isPresent(int v){
    for(int i=0;i<pc-1;i++){
      if(path[i]==v){
        return true;
      }
    }
    return false;
  }
  static void display(){
    System.out.println("Path: ");
    for(int i=0;i<=V;i++){
      System.out.print(path[i%V]+" ");
    }
    System.out.println();
  }
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of vertieces: ");
    int n = sc.nextInt();
    int graph[][] = new int[n][n];
    System.out.println("Enter the adj matrix: ");
    for(int i=0;i<n;i++){
      for(int j=0;j<n;j++){
        graph[i][j] = sc.nextInt();
      }
    }
    findCycle(graph);
  }
}
