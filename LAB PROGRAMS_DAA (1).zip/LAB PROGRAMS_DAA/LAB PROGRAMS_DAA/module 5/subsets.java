import java.util.*;
class subsets{
  static int c=0;
  public static void main(String[] args) {
    int x[] = new int[10];
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of ele: ");
    int n = sc.nextInt();
    System.out.println("enter the ele in inc order: ");
    int w[] = new int[10];
    for(int i=0;i<n;i++){
      w[i] = sc.nextInt();
    }
    System.out.println("Enter the positive sum: ");
    int d = sc.nextInt();
    int sum = 0;
    for(int i=0;i<n;i++){
      sum+=w[i];
    }
    if(sum<d || w[0]>d){
      System.out.println("no solution");
      System.exit(0);
    }
    subset(0,0,sum,x,w,d);
    if(c==0){
      System.out.println("no solution");
    }

  }
  static void subset(int cs,int k,int r,int x[],int w[],int d){
    x[k]=1;
    if(cs+w[k]==d){
      c++;
      System.out.println("solution "+c+": {");
      for(int i=0;i<=k;i++){
        if(x[i]==1){
          System.out.print(w[i]+",");
        }
      }
      System.out.println("}");
    }
    else if(cs+w[k]+w[k+1]<=d){
      subset(cs+w[k],k+1,r-w[k],x,w,d);
    }
    if((cs+r-w[k])>=d && (cs+w[k+1])<=d){
      x[k] = 0;
      subset(cs,k+1,r-w[k],x,w,d);
    }
  }
}
