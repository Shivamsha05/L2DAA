import java.util.*;

public class BellmanFord {
    static class Edge {
        int source, destination, weight;
    }
    static void bellmanFord(int V, int E, Edge[] edges, int src) {
        int[] dist = new int[V];
        for (int i = 0; i < V; i++)
            dist[i] = Integer.MAX_VALUE;
        dist[src] = 0;

        for (int i = 1; i < V; i++) {
            for (Edge e : edges) {
                int u = e.source;
                int v = e.destination;
                int w = e.weight;
                if (dist[u] != Integer.MAX_VALUE && dist[u] + w < dist[v])
                    dist[v] = dist[u] + w;
            }
        }     
        for (Edge e : edges) {
            int u = e.source;
            int v = e.destination;
            int w = e.weight;
            if (dist[u] != Integer.MAX_VALUE && dist[u] + w < dist[v])
                System.out.println("Graph contains negative weight cycle");
        }   
        for (int i = 0; i < V; i++)
            System.out.println("Distance from source " + src + " to vertex " + i + " is " + dist[i]);
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of vertices:");
        int V = scanner.nextInt();

        System.out.println("Enter the number of edges:");
        int E = scanner.nextInt();

        Edge[] edges = new Edge[E];

        System.out.println("Enter the source, destination, and weight of each edge:");
        for (int i = 0; i < E; i++) {
            edges[i] = new Edge();
            edges[i].source = scanner.nextInt();
            edges[i].destination = scanner.nextInt();
            edges[i].weight = scanner.nextInt();
        }
        System.out.println("Enter the source vertex:");
        int src = scanner.nextInt();
        bellmanFord(V, E, edges, src);
    }
}