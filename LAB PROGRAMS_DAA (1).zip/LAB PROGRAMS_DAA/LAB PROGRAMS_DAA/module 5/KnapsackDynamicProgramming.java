import java.util.Scanner;

class Item {
    float weight;
    int value;

    Item(float weight, int value) {
        this.weight = weight;
        this.value = value;
    }
}

public class KnapsackDynamicProgramming {

    public static int knapsack(int W, Item[] arr, int n) {
        int[][] dp = new int[n + 1][W + 1];

        for (int i = 1; i <= n; i++) {
            float weight = arr[i - 1].weight;
            int value = arr[i - 1].value;
            for (int w = 0; w <= W; w++) {
                if (weight <= w) {
                    dp[i][w] = Math.max(dp[i - 1][w], dp[i - 1][(int) (w - weight)] + value);
                } else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }

        return dp[n][W];
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of items: ");
        int n = scanner.nextInt();

        Item[] arr = new Item[n];

        System.out.println("Enter the weight and value of each item:");
        for (int i = 0; i < n; i++) {
            System.out.print("Weight of item " + (i + 1) + ": ");
            float weight = scanner.nextFloat();
            System.out.print("Value of item " + (i + 1) + ": ");
            int value = scanner.nextInt();
            arr[i] = new Item(weight, value);
        }

        System.out.print("Enter the maximum capacity of the knapsack: ");
        int W = scanner.nextInt();

        scanner.close();

        int maxProfit = knapsack(W, arr, n);
        System.out.println("Maximum possible profit = " + maxProfit);
    }
}
