import java.util.*;
class nCr{
  static int fact(int n){
    if(n==1||n==0){
      return n;
    }
    return n*fact(n-1);
  }
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter n: ");
    int n = sc.nextInt();
    System.out.println("Enter r: ");
    int r = sc.nextInt();
    int res = fact(n)/(fact(n-r)*fact(r));
    System.out.println("Result: "+res);
  }
}
