import java.util.*;
class Binary{
  static void search(int arr[],int key,int n){
    int l = 0;
    int h = n-1;
    while(l<=h){
      int mid = (l+h)/2;
      if(arr[mid]==key){
        System.out.println("Key found at  pos : "+mid+1);
        System.exit(0);
      }
      if(arr[mid]>key){
        h = mid-1;
      }
      if(arr[mid]<key){
        l = mid+1;
      }
    }
    System.out.println("Key not found");
  }
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter size : ");
    int n = sc.nextInt();
    System.out.println("Enter array elements : ");
    int arr[] = new int[10];
    for(int i=0;i<n;i++){
      arr[i] = sc.nextInt();
    }
    System.out.println("enter key to be searched : ");
    int key = sc.nextInt();
    search(arr,key,n);
  }

}
