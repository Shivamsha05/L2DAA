import java.util.*;
public class Linear{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("n: ");
        int n = sc.nextInt();
        System.out.println("Enetr array ele : ");
        int arr[] = new int[n];
        int flag=0,pos=0;
        for(int i =0;i<n;i++){
            arr[i]=sc.nextInt();
          }
          System.out.println("Enter key : ");
          int key = sc.nextInt();
        for(int i=0;i<n;i++){
            if(arr[i]==key){
                flag=1;
                pos = i+1;
              }
          }
        
        if(flag==1){
            System.out.println("Ele found at pos: "+pos);
          }
          else{
              System.out.println("ele not found");
            }
      }
} 
