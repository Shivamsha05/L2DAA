import java.util.*;
import java.io.*;
public class 01knapsack{
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int v[][] = new int[50][50];
    int w[] = new int[50];
    int p[] = new int[50];
    System.out.println("Enter the number of items: ");
    int n = sc.nextInt();
    System.out.println("Enter the weight of each item : ");
    for(int i=0;i<=n;i++){
      w[i] = sc.nextInt();
    }
    System.out.println("enter profit: ");
    for(int i=0;i<=n;i++){
      p[i] = sc.nextInt();
    }
    System.out.println("enter the capacity: ");
    int m = sc.nextInt();
    display(n,w,p);
    System.out.println("Capaicty is: "+m);
    knapsack(m,n,w,p,v);
    System.out.println("Contents of knapsack: ");
    for(int i=0;i<=n;i++){
      for(int j=0;j<=n;j++){
        System.out.print(v[i][j]+" ");
      }
      System.out.println();
    }
    optimal(m,n,w,v);
  }
  void display(int n,int w[],int p[]){
    System.out.println("no.\tWeight\tProfit");
    for(int i=0;i<=n;i++){
      System.out.print(n+"\t"+w[i]+"\t"+p[i]);
    }
    System.out.println();
  }
  static void knapsack(int m,int n,int w[],int p[],int v[][]){
    for(int i=0;i<=n;i++){
      for(int j=0;j<=n;j++){
        if(i==0||j==0){
          v[i][j]=0;
        }
        else if(j<cos[i]){
          v[i][j] = v[i-1][j];
        }
        else{
          v[i][j] = max(v[i-1][j],(v[i-1][j-w[i]]+p[i]));
        }
      }
    }
  }
  private static int max(int i,int j){
    if(i>j){
      return i;
    }
    return j;
  }
  static void optimal(int m,int n,int w[],int v[][]){
    int i=n,j=m,item=0,x[] =new int[10];
    while(i!=0 && j!=0){
      if(v[i][j]!=v[j-1][j]){
        x[i] = 1;
        j=j-w[i];
      }
      i=i-1;
    }
    System.out.println("the optimal solun is: "+v[n][m]);
    System.out.println("The items are: ");
    for(i=0;i<=n;i++){
      if(x[i]==1){
        System.out.println(i+" ");
        item=1;
      }
      if(item==0){
        System.out.println("no items");
      }
    }
  }
}
